﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Web.Script.Serialization;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace MyRecipes
{
    public class RecipeDBData : IRecipeData
    {
        MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ToString());

        public RecipeDBData() { }  
        
        public override ArrayList GetRecipeHeadings()
        {
            if (connection.State == System.Data.ConnectionState.Closed)
                connection.Open();

            string recipeQuery = "SELECT * FROM recipe";

            int recipeID;
            string re_name;
            string description;
            string image;
            
            MySqlCommand recipeCmd = new MySqlCommand(recipeQuery, connection);
            MySqlDataReader recipeDataReader = recipeCmd.ExecuteReader();

            ArrayList _recipes = new ArrayList();

            while (recipeDataReader.Read())
            {
                recipeID = Convert.ToInt32(recipeDataReader["recipeID"]);
                re_name = Convert.ToString(recipeDataReader["re_name"]);
                description = Convert.ToString(recipeDataReader["description"]);
                image = Convert.ToString(recipeDataReader["image"]);

                Recipe recipe = new Recipe(recipeID, re_name, description, image);
                _recipes.Add(recipe);
            }
            connection.Close();
            return _recipes;
        }
        
        public override ArrayList SearchRecipes(string keyword)
        {
            if (connection.State == System.Data.ConnectionState.Closed)
                connection.Open();
            ArrayList _recipes = new ArrayList();
            
            string query = "SELECT * FROM recipe WHERE MATCH(ingredients) AGAINST (@keyword IN NATURAL LANGUAGE MODE)";
           
            MySqlCommand cmd = new MySqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@keyword", keyword);
            MySqlDataReader dataReader = cmd.ExecuteReader();

            int recipeID;
            string re_name;
            string description;
            int re_time;
            string ingredients;
            string instructions;
            string image;
            string username;
            while (dataReader.Read())
            {
                recipeID = Convert.ToInt32(dataReader["recipeID"]);
                re_name = Convert.ToString(dataReader["re_name"]);
                description = Convert.ToString(dataReader["description"]);
                re_time = Convert.ToInt32(dataReader["re_time"]);
                ingredients = Convert.ToString(dataReader["ingredients"]);
                instructions = Convert.ToString(dataReader["instructions"]);
                image = Convert.ToString(dataReader["image"]);
                username = Convert.ToString(dataReader["userName"]);

                Recipe recipe = new Recipe(recipeID, re_name, description, re_time, ingredients, instructions, image, username);
                _recipes.Add(recipe);
            }
            connection.Close();
            return _recipes;
        }

        public override Recipe GetRecipe(int id)
        {
            if(connection.State == System.Data.ConnectionState.Closed)
                connection.Open();

            string query = "SELECT * FROM recipe LEFT OUTER JOIN usercomment ON recipe.recipeID = usercomment.recipeID WHERE recipe.recipeID = @id";

            int recipeID;
            string re_name;
            string description;
            int re_time;
            string ingredients;
            string instructions;
            string image;
            string username;
            string cmtUser;
            string comment;
            
            MySqlCommand cmd = new MySqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@id",id);
            MySqlDataReader recipeDataReader = cmd.ExecuteReader();

            Recipe recipe = null;

            ArrayList _comments = new ArrayList();
            while (recipeDataReader.Read())
            {
                recipeID = Convert.ToInt32(recipeDataReader["recipeID"]);
                re_name = Convert.ToString(recipeDataReader["re_name"]);
                description = Convert.ToString(recipeDataReader["description"]);
                re_time = Convert.ToInt32(recipeDataReader["re_time"]);
                ingredients = Convert.ToString(recipeDataReader["ingredients"]);
                instructions = Convert.ToString(recipeDataReader["instructions"]);
                image = Convert.ToString(recipeDataReader["image"]);
                username = Convert.ToString(recipeDataReader["userName"]);

                recipe = new Recipe(recipeID, re_name, description, re_time, ingredients, instructions, image, username);

                cmtUser = Convert.ToString(recipeDataReader["userCmtName"]);
                comment = Convert.ToString(recipeDataReader["userCmt"]);
                if (comment != "")
                    _comments.Add(new UserComment(cmtUser, comment));
            }
            for (int i = 0; i < _comments.Count; i++)
            {
                UserComment uCmt = (UserComment)_comments[i];
                string user = uCmt.UserName;
                string cmt = uCmt.Comment;
                recipe.AddComment(user, cmt);
            }
            connection.Close();
            return recipe;
        }

        public override Recipe AddRecipe(string name, string description, int time, string ingredients, string instruction, string image)
        {
            string username = HttpContext.Current.Session["UserName"].ToString();
            Recipe tmpRecipe = new Recipe(10, name, description, time, ingredients, instruction, image, username);
            if (connection.State == System.Data.ConnectionState.Closed)
                connection.Open();

            string query = "INSERT INTO recipe(re_name, description, re_time, ingredients, instructions, image, userName) VALUES " +
                "(@name,@description,@time,@ingredients,@instruction,@image, @username)";
            MySqlCommand cmd = new MySqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@description", description);
            cmd.Parameters.AddWithValue("@time", time);
            cmd.Parameters.AddWithValue("@ingredients", ingredients);
            cmd.Parameters.AddWithValue("@instruction", instruction);
            cmd.Parameters.AddWithValue("@image", image);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.ExecuteNonQuery();

            string lastIdQuery = "SELECT recipeID FROM recipe WHERE userName = @userName ORDER BY recipeID DESC LIMIT 1";
            MySqlCommand idCmd = new MySqlCommand(lastIdQuery, connection);
            idCmd.Parameters.AddWithValue("@userName", username);
            idCmd.ExecuteNonQuery();
            MySqlDataReader dataReader = idCmd.ExecuteReader();
            bool check = dataReader.HasRows;
            int id = 0;
            if (dataReader.Read())
            {
                id = Convert.ToInt32(dataReader["recipeID"]);
            }

            connection.Close();

            Recipe newRecipe = new Recipe(id, name, description, time, ingredients, instruction, image, username);
            return newRecipe;
        }

        public override void AddComment(int recipeId, string comment)
        {
            if (connection.State == System.Data.ConnectionState.Closed)
                connection.Open();
            
            string username = HttpContext.Current.Session["UserName"].ToString();
            if (username == "")
            {
                throw new System.ApplicationException("Guest user cannot add comment");
            }
            
            string query = "INSERT INTO usercomment(recipeID, userCmtName, userCmt) VALUES (" +
                "@id, @username, @comment)";
               
            MySqlCommand cmd = new MySqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@id", recipeId);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@comment", comment);
            cmd.ExecuteNonQuery();
            connection.Close();
        }
    }
}