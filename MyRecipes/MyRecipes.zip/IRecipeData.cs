﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyRecipes
{
    public abstract class IRecipeData
    {
        public abstract ArrayList GetRecipeHeadings();
        public abstract ArrayList SearchRecipes(string keywords);
        public abstract Recipe GetRecipe(int id);
        public abstract Recipe AddRecipe(string name, string description, int time, string ingredients, string instruction, string image);
        public abstract void AddComment(int recipeID, string comment);
    }
}