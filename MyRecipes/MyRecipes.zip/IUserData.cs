﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyRecipes
{
    public abstract class IUserData
    {
        public abstract void Login(User checkUser);
        public abstract void Register(User newUser, string repassword);
        public abstract void Logout();
    }
}